
<?php $__env->startSection('content'); ?>
    <div class="container mt-2">
        <h1 class="text-center">Detail Tugas</h1>
        <hr>
        <div class="card">
            <div class="card-body">
                <h4 class="card-title"><?php echo e($task['name']); ?></h4>
                <p class="card-text"><strong>Deadline:</strong> <?php echo e(\Carbon\Carbon::parse($task['deadline'])->format('d F Y')); ?></p>
                <p class="card-text"><strong>Status:</strong> <span class="badge bg-warning"><?php echo e($task['status']); ?></span></p>
                <p class="card-text"><strong>Deskripsi:</strong> <?php echo e($task['description']); ?></p>
            </div>
        </div>
        <div class="mt-3">
        <a href="/tasks" class="btn btn-primary">Kembali ke Daftar Tugas</a>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JarvisCamp\Laravel_Models\resources\views/task/show.blade.php ENDPATH**/ ?>