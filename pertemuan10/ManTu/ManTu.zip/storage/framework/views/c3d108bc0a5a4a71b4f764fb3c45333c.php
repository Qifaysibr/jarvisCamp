<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Tambah Data Tugas</h1>

        <div class="card">
            <div class="card-body">
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('tasks.update', $task->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    <div class="form-group row mb-3">
                        <label for="name" class="col-4 col-form-label">Nama</label>
                        <div class="col-8">
                            <input id="name" name="name" placeholder="Masukan Nama Tugas" type="text"
                                class="form-control" value="<?php echo e($task->name); ?>">
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label for="deadline" class="col-4 col-form-label">Deadline</label>
                        <div class="col-8">
                            <input id="deadline" name="deadline" type="date" class="form-control"
                                value="<?php echo e($task->deadline); ?>">
                        </div>
                    </div>

                    <div class="form-group row mb-3">
                        <label for="status" class="col-4 col-form-label">Status</label>
                        <div class="col-8">
                            <select id="status" name="status" class="form-control">
                                <option value="">pilih status</option>
                                <option value="belum dikerjakan"
                                    <?php echo e($task->status == 'belum dikerjakan' ? 'selected' : ''); ?>>belum dikerjakan
                                </option>
                                <option value="sedang dikerjakan"
                                    <?php echo e($task->status == 'sedang dikerjakan' ? 'selected' : ''); ?>>sedang dikerjakan
                                </option>
                                <option value="selesai" <?php echo e($task->status == 'selesai' ? 'selected' : ''); ?>>selesai
                                </option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <label for="description" class="col-4 col-form-label">Deskripsi</label>
                        <div class="col-8">
                            <textarea id="description" name="description" cols="40" rows="4" class="form-control"
                                value="<?php echo e($task->description); ?>"><?php echo e($task->description); ?></textarea>
                        </div>
                    </div>
                    <div class="form-group row mb-3">
                        <div class="offset-4 col-8">
                            <button name="submit" type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\JarvisCamp\Laravel_Models\resources\views/task/edit.blade.php ENDPATH**/ ?>