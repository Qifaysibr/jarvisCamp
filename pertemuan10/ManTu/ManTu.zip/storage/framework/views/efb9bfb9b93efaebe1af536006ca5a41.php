
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h2 class="text-center mt-3">Daftar Tugas</h2>
        <hr>

        <div class="row">
            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-12 col-md-4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <h4 class="card-title"><?php echo e($task['name']); ?></h4>
                            <small>Deadline: <?php echo e(\Carbon\Carbon::parse($task['deadline'])->format('d F Y')); ?></small><br>
                            <span class="badge bg-warning"><?php echo e($task['status']); ?></span>
                            <p class="card-text"><?php echo e(Str::limit($task['description'], 40, '...')); ?></p>

                            <!-- Updated snippet of resources/views/tasks/index.blade.php -->
                            <div class="mt-2">
                                <a href="<?php echo e(route('task.detail', $task['id'])); ?>" class="btn btn-warning">Detail</a>
                            </div>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous">
</script>
</body>

</html>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jarvisCamp\pertemuan10\ManTu\resources\views/task/index.blade.php ENDPATH**/ ?>