
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h1>Daftar Tabel Tugas</h1>

        <div class="card mt-3">
            <div class="card-header">
                <h3>Data Tabel</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-primary btn-sm">Tambah Data</a>
                    <table class="table table-border">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Status</th>
                                <th>Deadline</th>
                                <th>Deskripsi</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($task->name); ?></td>
                                    <td><?php echo e($task->status); ?></td>
                                    <td><?php echo e($task->deadline); ?></td>
                                    <td><?php echo e(substr($task->description, 0, '50')); ?>...</td>
                                    <td class="d-flex">
                                        <a href="<?php echo e(route('tasks.edit', $task->id)); ?>"
                                            class="btn btn-warning btn-sm mb-2 me-2">Edit</a>
                                        <form action="<?php echo e(route('tasks.delete', $task->id)); ?>" method="POST"
                                            onsubmit="return confirm('Apakah Anda yakin ingin menghapus task ini?');">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm mb-2">Hapus</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jarvisCamp\pertemuan10\ManTu\resources\views/task/list.blade.php ENDPATH**/ ?>